import './styles.css';
import 'phaser';

import { SpringrollGame } from './SpringrollGame';