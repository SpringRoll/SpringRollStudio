export const GAMEPLAY = Object.freeze(
{
    WIDTH: 1320,
    HEIGHT: 780,
    GRAVITY: 0.098
});